# 🎬 API de Filmes

API RESTful desenvolvida em **Node.js** com **Express** e **Sequelize** para gerenciar **Filmes** e **Diretores**.

## 🚀 Tecnologias
- Node.js
- Express
- Sequelize (ORM)
- MySQL

## 📂 Estrutura do Projeto
- `src/config` → Configuração do banco de dados
- `src/models` → Modelos (tabelas do banco)
- `src/controllers` → Regras de negócio (CRUD)
- `src/routes` → Rotas da API
- `src/app.js` → Configuração principal do servidor

## 🔧 Como rodar
1. Crie o banco de dados no MySQL:
   ```sql
   CREATE DATABASE filmesdb;
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Rode em modo desenvolvimento:
   ```bash
   npm run dev
   ```

4. Acesse no navegador ou Postman:
   - `GET http://localhost:3333/api/diretores`
   - `POST http://localhost:3333/api/diretores`
   - `GET http://localhost:3333/api/filmes`
   - `POST http://localhost:3333/api/filmes`

## 📌 Endpoints

### Diretores
- `GET /api/diretores` → Lista todos os diretores
- `POST /api/diretores` → Cadastra um novo diretor

### Filmes
- `GET /api/filmes` → Lista todos os filmes com seus diretores
- `POST /api/filmes` → Cadastra um novo filme

---
Desenvolvido para estudo 🚀
