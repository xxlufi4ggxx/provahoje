import express from "express";
import cors from "cors";
import { conn } from "./config/sequelize.js";

import "./models/associations.js";
import diretorRoutes from "./routes/diretorRoutes.js";
import filmeRoutes from "./routes/filmeRoutes.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/diretores", diretorRoutes);
app.use("/api/filmes", filmeRoutes);

conn.sync()
  .then(() => console.log("✅ Banco sincronizado"))
  .catch(err => console.error("❌ Erro ao conectar:", err));

const PORT = 3333;
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});

export default app;