import { Sequelize } from "sequelize";

export const conn = new Sequelize("filmesdb", "root", "", {
  host: "localhost",
  dialect: "mysql",
});