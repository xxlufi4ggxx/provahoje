import { Diretor } from "../models/associations.js";

export const listarDiretores = async (req, res) => {
  try {
    const diretores = await Diretor.findAll();
    res.status(200).json(diretores);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao listar diretores" });
  }
};

export const criarDiretor = async (req, res) => {
  try {
    const { nome, nacionalidade } = req.body;
    const novo = await Diretor.create({ nome, nacionalidade });
    res.status(201).json(novo);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar diretor" });
  }
};