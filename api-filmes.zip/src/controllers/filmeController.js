import { Filme, Diretor } from "../models/associations.js";

export const listarFilmes = async (req, res) => {
  try {
    const filmes = await Filme.findAll({
      include: { model: Diretor, as: "diretor" }
    });
    res.status(200).json(filmes);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao listar filmes" });
  }
};

export const criarFilme = async (req, res) => {
  try {
    const { titulo, ano, genero, diretorId } = req.body;
    const novo = await Filme.create({ titulo, ano, genero, diretorId });
    res.status(201).json(novo);
  } catch (err) {
    res.status(500).json({ erro: "Erro ao criar filme" });
  }
};