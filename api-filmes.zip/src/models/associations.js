import Diretor from "./diretorModel.js";
import Filme from "./filmeModel.js";

Diretor.hasMany(Filme, { foreignKey: "diretorId", as: "filmes" });
Filme.belongsTo(Diretor, { foreignKey: "diretorId", as: "diretor" });

export { Diretor, Filme };