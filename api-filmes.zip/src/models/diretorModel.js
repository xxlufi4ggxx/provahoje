import { DataTypes } from "sequelize";
import { conn } from "../config/sequelize.js";

const Diretor = conn.define("diretores", {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  nome: { type: DataTypes.STRING, allowNull: false },
  nacionalidade: { type: DataTypes.STRING, allowNull: false }
}, {
  tableName: "diretores",
  timestamps: true
});

export default Diretor;