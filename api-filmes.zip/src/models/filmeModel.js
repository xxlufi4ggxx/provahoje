import { DataTypes } from "sequelize";
import { conn } from "../config/sequelize.js";

const Filme = conn.define("filmes", {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  titulo: { type: DataTypes.STRING, allowNull: false },
  ano: { type: DataTypes.INTEGER, allowNull: false },
  genero: { type: DataTypes.STRING, allowNull: false }
}, {
  tableName: "filmes",
  timestamps: true
});

export default Filme;