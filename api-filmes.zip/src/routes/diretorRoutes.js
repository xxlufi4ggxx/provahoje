import { Router } from "express";
import { listarDiretores, criarDiretor } from "../controllers/diretorController.js";

const router = Router();
router.get("/", listarDiretores);
router.post("/", criarDiretor);
export default router;