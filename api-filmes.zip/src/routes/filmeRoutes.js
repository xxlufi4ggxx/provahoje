import { Router } from "express";
import { listarFilmes, criarFilme } from "../controllers/filmeController.js";

const router = Router();
router.get("/", listarFilmes);
router.post("/", criarFilme);
export default router;